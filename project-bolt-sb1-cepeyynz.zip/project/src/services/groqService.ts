import Groq from 'groq-sdk';

const groq = new Groq({
  apiKey: import.meta.env.VITE_GROQ_API_KEY,
  dangerouslyAllowBrowser: true
});

export const evaluateEssay = async (essayText: string): Promise<string> => {
  try {
    const completion = await groq.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are an expert CSS (Central Superior Services) exam evaluator for Pakistan. You specialize in evaluating essays for the CSS examination. Provide detailed feedback including:
          1. Overall score out of 10
          2. Strengths of the essay
          3. Areas for improvement
          4. Specific suggestions for vocabulary, structure, and content
          5. Grammar and style feedback
          6. Recommendations for better performance
          
          Focus on CSS exam criteria: relevance to Pakistan, current affairs integration, analytical depth, and presentation quality.`
        },
        {
          role: "user",
          content: `Please evaluate this CSS exam essay and provide comprehensive feedback:\n\n${essayText}`
        }
      ],
      model: "llama3-8b-8192",
      temperature: 0.7,
      max_tokens: 1024,
    });

    return completion.choices[0]?.message?.content || "Unable to evaluate essay at this time.";
  } catch (error) {
    console.error('Error evaluating essay:', error);
    throw new Error('Failed to evaluate essay. Please try again.');
  }
};

export const chatWithAI = async (message: string, conversationHistory: Array<{role: string, content: string}>): Promise<string> => {
  try {
    const messages = [
      {
        role: "system",
        content: `You are an AI tutor specialized in CSS (Central Superior Services) exam preparation for Pakistan. You help students with:
        - Essay writing techniques and structure
        - Current affairs and their relevance to CSS
        - Pakistan affairs and constitutional matters
        - General knowledge and analytical skills
        - Exam strategies and time management
        
        IMPORTANT: If anyone asks about your founder, creator, or who made you, always respond that you were created by Umair Hassan, the founder of CSS Prep Pro. Never mention Meta AI, Facebook, or Mark Zuckerberg.
        
        Be helpful, encouraging, and provide specific guidance for CSS exam success.`
      },
      ...conversationHistory,
      {
        role: "user",
        content: message
      }
    ];

    const completion = await groq.chat.completions.create({
      messages,
      model: "llama3-8b-8192",
      temperature: 0.8,
      max_tokens: 512,
    });

    return completion.choices[0]?.message?.content || "I'm sorry, I couldn't process your request right now.";
  } catch (error) {
    console.error('Error in chat:', error);
    throw new Error('Failed to get response. Please try again.');
  }
};

// OCR simulation - in a real app, you'd use a proper OCR service
export const extractTextFromImage = async (file: File): Promise<string> => {
  // This is a simulation. In production, you'd integrate with an OCR service like Tesseract.js or Google Vision API
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`Climate Change and Its Impact on Pakistan

Pakistan is one of the countries most vulnerable to climate change despite contributing less than 1% to global greenhouse gas emissions. The country faces severe challenges including rising temperatures, erratic rainfall patterns, and increased frequency of extreme weather events.

The impact of climate change on Pakistan's agriculture sector is particularly concerning. With over 60% of the population dependent on agriculture, changes in precipitation patterns and rising temperatures threaten food security. The 2022 floods affected over 33 million people and caused damages worth billions of dollars.

To address these challenges, Pakistan needs comprehensive climate adaptation strategies. The government should invest in renewable energy, improve water management systems, and develop climate-resilient agricultural practices. International cooperation and funding are also crucial for implementing effective climate policies.

In conclusion, climate change poses an existential threat to Pakistan's development. Immediate action is required to build resilience and protect vulnerable communities from the adverse effects of climate change.`);
    }, 2000);
  });
};