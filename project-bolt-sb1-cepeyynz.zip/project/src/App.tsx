import React, { useState } from 'react';
import Header from './components/Header';
import Home from './components/Home';
import EssayUpload from './components/EssayUpload';
import ChatBot from './components/ChatBot';
import Progress from './components/Progress';

function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <Home />;
      case 'upload':
        return <EssayUpload />;
      case 'chat':
        return <ChatBot />;
      case 'progress':
        return <Progress />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />
      {renderContent()}
    </div>
  );
}

export default App;