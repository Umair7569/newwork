import React from 'react';
import { TrendingUp, Award, Clock, BookOpen, Target, CheckCircle } from 'lucide-react';

export default function Progress() {
  const stats = [
    { label: 'Essays Evaluated', value: '24', icon: BookOpen, color: 'bg-blue-500' },
    { label: 'Average Score', value: '7.2/10', icon: Award, color: 'bg-green-500' },
    { label: 'Study Hours', value: '48h', icon: Clock, color: 'bg-purple-500' },
    { label: 'Improvement', value: '+15%', icon: TrendingUp, color: 'bg-yellow-500' }
  ];

  const recentEssays = [
    { title: 'Role of Youth in National Development', score: 8.5, date: '2024-01-15', status: 'completed' },
    { title: 'Climate Change and Pakistan', score: 7.8, date: '2024-01-14', status: 'completed' },
    { title: 'Digital Pakistan Initiative', score: 6.9, date: '2024-01-13', status: 'needs-improvement' },
    { title: 'Women Empowerment in Pakistan', score: 8.2, date: '2024-01-12', status: 'completed' }
  ];

  const strengths = [
    'Strong thesis development',
    'Good use of examples',
    'Clear essay structure',
    'Relevant current affairs'
  ];

  const improvements = [
    'Enhance vocabulary usage',
    'Improve paragraph transitions',
    'Add more statistical data',
    'Work on conclusion strength'
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Your Progress Dashboard</h1>
          <p className="text-lg text-gray-600">Track your CSS exam preparation journey</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                </div>
                <p className="text-gray-600 font-medium">{stat.label}</p>
              </div>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Recent Essays */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <BookOpen className="h-5 w-5 mr-2 text-blue-600" />
              Recent Essays
            </h2>
            <div className="space-y-4">
              {recentEssays.map((essay, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-gray-900">{essay.title}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      essay.status === 'completed' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {essay.status === 'completed' ? 'Good' : 'Needs Work'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <span>{essay.date}</span>
                    <span className="font-semibold text-gray-900">Score: {essay.score}/10</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Performance Chart */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-green-600" />
              Score Trend
            </h2>
            <div className="h-64 flex items-end justify-between space-x-2">
              {[6.5, 7.2, 6.8, 7.5, 8.1, 7.8, 8.5].map((score, index) => (
                <div key={index} className="flex flex-col items-center flex-1">
                  <div 
                    className="w-full bg-gradient-to-t from-green-500 to-green-400 rounded-t"
                    style={{ height: `${(score / 10) * 200}px` }}
                  />
                  <span className="text-xs text-gray-600 mt-2">{score}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Strengths */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
              Your Strengths
            </h2>
            <div className="space-y-3">
              {strengths.map((strength, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span className="text-gray-700">{strength}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Areas for Improvement */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <Target className="h-5 w-5 mr-2 text-yellow-600" />
              Focus Areas
            </h2>
            <div className="space-y-3">
              {improvements.map((improvement, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                  <span className="text-gray-700">{improvement}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}