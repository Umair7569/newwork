import React from 'react';
import { BookOpen, Target, TrendingUp, Award, Clock, Users } from 'lucide-react';

export default function Home() {
  const features = [
    {
      icon: BookOpen,
      title: 'Comprehensive Study Material',
      description: 'Access curated content covering all CSS exam subjects including Pakistan Affairs, Current Affairs, and Essay Writing.',
      color: 'bg-blue-500'
    },
    {
      icon: Target,
      title: 'AI-Powered Essay Evaluation',
      description: 'Upload handwritten essays and get instant feedback with detailed corrections and improvement suggestions.',
      color: 'bg-green-500'
    },
    {
      icon: TrendingUp,
      title: 'Progress Tracking',
      description: 'Monitor your improvement over time with detailed analytics and personalized study recommendations.',
      color: 'bg-purple-500'
    },
    {
      icon: Award,
      title: 'Expert Guidance',
      description: 'Get mentorship from successful CSS officers and access proven strategies for exam success.',
      color: 'bg-yellow-500'
    }
  ];

  const stats = [
    { icon: Users, value: '5000+', label: 'Students Enrolled' },
    { icon: Award, value: '85%', label: 'Success Rate' },
    { icon: Clock, value: '24/7', label: 'AI Support' },
    { icon: BookOpen, value: '50+', label: 'Study Modules' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50">
      {/* Hero Section */}
      <section className="relative py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="mb-8">
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              Master the <span className="text-green-600">CSS Exam</span> with AI
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Pakistan's most advanced CSS preparation platform. Upload your handwritten essays, 
              get AI-powered evaluations, and excel in the Central Superior Services examination.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <button className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg">
              Start Essay Evaluation
            </button>
            <button className="border-2 border-green-600 text-green-600 hover:bg-green-600 hover:text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all">
              Chat with AI Tutor
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-green-100 rounded-lg mb-4">
                    <Icon className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                  <div className="text-gray-600 text-sm">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Why Choose CSS Prep Pro?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Advanced AI technology meets expert knowledge to give you the competitive edge in CSS preparation.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="group">
                  <div className="bg-gray-50 rounded-xl p-8 h-full transition-all duration-300 hover:shadow-xl hover:-translate-y-2">
                    <div className={`inline-flex items-center justify-center w-12 h-12 ${feature.color} rounded-lg mb-6 group-hover:scale-110 transition-transform`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">{feature.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-green-600 to-green-700">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Ace Your CSS Exam?
          </h2>
          <p className="text-xl text-green-100 mb-8 leading-relaxed">
            Join thousands of successful candidates who used our AI-powered platform to achieve their dreams.
          </p>
          <button className="bg-white text-green-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg">
            Get Started Now
          </button>
        </div>
      </section>
    </div>
  );
}