import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText, CheckCircle, AlertCircle, Loader } from 'lucide-react';
import { extractTextFromImage, evaluateEssay } from '../services/groqService';

export default function EssayUpload() {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [evaluation, setEvaluation] = useState<string>('');
  const [error, setError] = useState<string>('');

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setUploadedFile(file);
      setEvaluation('');
      setError('');
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif']
    },
    maxFiles: 1
  });

  const evaluateEssay = async () => {
    if (!uploadedFile) return;

    setIsProcessing(true);
    setError('');

    try {
      // Extract text from uploaded image
      const extractedText = await extractTextFromImage(uploadedFile);
      
      // Get AI evaluation
      const evaluationResult = await evaluateEssay(extractedText);
      setEvaluation(evaluationResult);

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process essay. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Essay Evaluation</h1>
          <p className="text-lg text-gray-600">Upload your handwritten essay for AI-powered evaluation and feedback</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Upload Section */}
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <Upload className="h-5 w-5 mr-2 text-green-600" />
              Upload Essay
            </h2>

            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                isDragActive ? 'border-green-500 bg-green-50' : 'border-gray-300 hover:border-green-400'
              }`}
            >
              <input {...getInputProps()} />
              {uploadedFile ? (
                <div className="space-y-4">
                  <CheckCircle className="h-12 w-12 text-green-500 mx-auto" />
                  <div>
                    <p className="text-lg font-medium text-gray-900">{uploadedFile.name}</p>
                    <p className="text-sm text-gray-500">File uploaded successfully</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <FileText className="h-12 w-12 text-gray-400 mx-auto" />
                  <div>
                    <p className="text-lg font-medium text-gray-900">
                      {isDragActive ? 'Drop your essay here' : 'Upload your essay'}
                    </p>
                    <p className="text-sm text-gray-500">
                      Drag & drop or click to select (JPEG, PNG, GIF)
                    </p>
                  </div>
                </div>
              )}
            </div>

            {uploadedFile && (
              <div className="mt-6">
                <button
                  onClick={evaluateEssay}
                  disabled={isProcessing}
                  className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white py-3 px-6 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-colors"
                >
                  {isProcessing ? (
                    <>
                      <Loader className="h-5 w-5 animate-spin" />
                      <span>Processing Essay...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="h-5 w-5" />
                      <span>Evaluate Essay</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {error && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start space-x-3">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <p className="text-red-700">{error}</p>
              </div>
            )}
          </div>

          {/* Evaluation Results */}
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Evaluation Results</h2>
            
            {evaluation ? (
              <div className="prose prose-sm max-w-none">
                <div className="whitespace-pre-wrap text-gray-700 leading-relaxed">
                  {evaluation}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-gray-400">
                <FileText className="h-16 w-16 mb-4" />
                <p className="text-lg">Upload an essay to see evaluation results</p>
              </div>
            )}
          </div>
        </div>

        {/* Tips Section */}
        <div className="mt-8 bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Essay Writing Tips</h3>
          <div className="grid md:grid-cols-2 gap-6 text-sm text-gray-700">
            <div>
              <h4 className="font-medium mb-2">Structure:</h4>
              <ul className="list-disc list-inside space-y-1">
                <li>Clear introduction with thesis statement</li>
                <li>3-4 well-developed body paragraphs</li>
                <li>Strong conclusion with recommendations</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Content:</h4>
              <ul className="list-disc list-inside space-y-1">
                <li>Use current affairs and statistics</li>
                <li>Include Pakistani context and examples</li>
                <li>Balance different perspectives</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}